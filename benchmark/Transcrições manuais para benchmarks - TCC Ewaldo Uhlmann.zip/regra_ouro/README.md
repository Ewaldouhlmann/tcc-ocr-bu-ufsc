# Regra ouro (ground truth)

Transcrição das 20 páginas de `manifest.csv`, uma por arquivo em
`{obra_slug}/{pagina}.txt`. Feita direto das imagens em
`data/corpus/images/`, sem consultar saídas de modelos (para não enviesar a
referência a favor de nenhum deles). **Status: rascunho, aguardando revisão
do autor e validação pelo NUPILL.**

## Convenções

- **Grafia diplomática**: ortografia, acentuação e erros tipográficos do
  original mantidos (`cazamento`, `hum`, `dòr`, `molhorar-me`, `querito`).
- **s longo**: registrado como `ſ` (O Feliz Independente). A métrica deve
  mapear `ſ → s` na normalização; assim dá para medir com e sem essa
  distinção.
- **Quebras de linha**: uma linha do arquivo por linha impressa; hifenização
  de fim de linha mantida (`afe-` / `tividade`). Linha em branco entre
  estrofes, blocos e títulos.
- **Pontuação**: colada à palavra anterior (`Velasco, e`, `Ah! si`). O espaço
  antes de vírgula/ponto típico da composição do séc. XVIII é tratado como
  espaçamento tipográfico, não como caractere.
- **Incluído**: títulos de seção, rubricas de personagem (`Ber.`, `S. Bern.`),
  datas e locais no pé dos poemas, notas de rodapé e suas chamadas (`(*)`),
  numeração de parágrafos (`19`, `20`), remissões no corpo (`(Pag. 53)`).
- **Excluído**: número de página, cabeçalho corrente (`HELOIZA`,
  `J. MARIANO DE OLIVEIRA`, `LIVRO I.`), reclamos (palavra repetida no pé da
  página, ex. `pri-`), assinaturas de caderno (`E iv`), vinhetas e asteriscos
  ornamentais (`* * *`), manchas.
- **Itálico/negrito/versalete**: não marcados (texto plano).
- **Glifos danificados** que claramente são a letra esperada foram
  transcritos como tal (`Ocidental`, `politicos` em Culto v2 p.100).

## Pontos para revisão

Leituras incertas, para conferir na imagem:

| Página | Trecho | Dúvida |
|---|---|---|
| heloiza/130 | `obscurantis-` | o hífen está fora da área visível (dobra da página) |
| heloiza/100 | — | o manifest fala em "nota de rodapé", mas a página não tem nota |
| culto_mulher_v1/035 | `molhorar-me` | parece erro tipográfico do original (melhorar) |
| culto_mulher_v1/035 | `déestes` | grafia confirmada na imagem, mas incomum |
| culto_mulher_v1/155 | `dòr` / `dôr` | o 1º tem acento grave, o 2º circunflexo |
| culto_mulher_v1/155 | `querito` | provável erro tipográfico (querido) |
| culto_mulher_v2/020 | `òra` | acento à esquerda do o, lido como grave |
| culto_mulher_v2/020 | `inecedivel` | assim impresso |
| culto_mulher_v2/050 | `Despanhava-se` | pode ser `Despenhava-se`; a impressão é fraca |
| culto_mulher_v2/050 | `doce` (fim da 1ª estrofe) | final da palavra cortado na margem |
| culto_mulher_v2/100 | `A. Conte.` | assim impresso (Comte) |
| culto_mulher_v2/170 | `tio, que` | o original tem `tio ,que` |
| amante_militar/065 | `Corónel` | acento visível na 1ª ocorrência, ausente na 2ª |
| amante_militar/095 | `galhardia, e` | sinal ambíguo entre `,` e `;` |
| feliz_independente/800 | `promp-` / `pta` | assim impresso (hifenização com `p` repetido) |
